def foo(a, b):
    return a + b

def test_foo():
    assert foo(3, 2) == 5