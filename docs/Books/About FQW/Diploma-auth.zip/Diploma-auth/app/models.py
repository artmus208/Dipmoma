class StepResponse():
    def __init__(self) -> None:
        self.ident_method = -1
    
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y
        
